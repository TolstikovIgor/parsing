import scrapy
from scrapy.http import HtmlResponse
from scrapy.loader import ItemLoader

from lesson_6.items import MyparseItem


class LeroySpider(scrapy.Spider):
    name = 'leroy'
    allowed_domains = ['leroymerlin.ru']

    def __init__(self, params):
        self.start_urls = [f'https://leroymerlin.ru/search/?q={params[0]}']

    def parse(self, response: HtmlResponse):
        good_links = response.xpath("//a[@slot='name']")
        for link in good_links:
            yield response.follow(link, callback=self.parse_good)

        next_page = response.css("a[rel='next']::attr(href)").extract_first()
        if next_page:
            yield response.follow(next_page, callback=self.parse)


    def parse_good(self, response:HtmlResponse):

        loader = ItemLoader(item=MyparseItem(), response=response)

        loader.add_xpath('name', "//h1[@slot='title']/text()")
        loader.add_xpath('photos', '//*[@slot="media-content"]//img[@itemprop="image"]/@src')
        loader.add_xpath('article', '//uc-pdp-card-ga-enriched/@data-product-id')
        loader.add_xpath('price', '//uc-pdp-card-ga-enriched//span[@slot="price"]/text()')
        loader.add_xpath('currency', '//uc-pdp-card-ga-enriched//span[@slot="currency"]/text()')
        loader.add_xpath('characteristics', '//dl[@class="def-list"]')
        yield loader.load_item()